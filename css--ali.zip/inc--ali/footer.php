<footer>
    <div class="main-footer" style="background-color: url(../img--ali/footer-bg.jpg) no-repeat;">
        <div class="container">

        </div>
    </div>
    <div class="ft-copy">
        <div class="container">

        </div>
    </div>
</footer>

<script src="../js/bootstrap.min.js"></script>
<script src="../js/jquery.min.js"></script>
<script src="../js/jquery.slimNav_sk78.min.js"></script>
<script src="../js/owl.carousel.js"></script>
<script src="../js/script.js"></script>
<script>
$('.car-slide').owlCarousel({
    loop: true,
    margin: 10,
    nav: true,
    responsive: {
        0: {
            items: 1
        },
        600: {
            items: 3
        },
        1000: {
            items: 5
        }
    }
})
</script>
</body>

</html>